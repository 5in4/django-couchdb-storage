name = "django_couchdb_storage"

from .CouchDBStorage import CouchDBStorage
